<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Search Teacher Replies</title>
</head>

<body>
<form action="search.php" method="POST">
	<input type="text" name="searchterm" placeholder="search here..."><br>
	<input type ="submit" value="Search">
</form>
</body>
</html>