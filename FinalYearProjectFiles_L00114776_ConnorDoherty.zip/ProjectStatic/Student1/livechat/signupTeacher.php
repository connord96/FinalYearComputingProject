<!DOCTYPE html>
<html>
<head>
	<title>Register a Teacher</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
	#signup_form{
		width:350px;
		height:430px;
		position:relative;
		top:50px;
		margin: auto;
		padding: auto;
	}
	#signup_form2{
		width:350px;
		height:700px;
		position:relative;
		top:50px;
		margin: auto;
		padding: auto;
	}
</style>
</head>
<body>
<div class="container">
	<div id="signup_form" class="well">
		<h2><center><span class="glyphicon glyphicon-user"></span> Provide Teacher Login</center></h2>
		<hr>
		<form method="POST" action="livechat/register1.php">
		Name: <input type="text" name="name" class="form-control" required>
		<div style="height: 10px;"></div>
		Username: <input type="text" name="username" class="form-control" required>
		<div style="height: 10px;"></div>		
		Password: <input type="password" name="password" class="form-control" required> 
		<div style="height: 10px;"></div>
		<button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span> Sign Up</button> 
		</form>
		<div style="height: 15px;"></div>
		<div style="color: red; font-size: 15px;">
			<center>
			<?php
				session_start();
				if(isset($_SESSION['sign_msg'])){
					echo $_SESSION['sign_msg'];
					unset($_SESSION['sign_msg']);
				}
				?>

			</center>
		</div>
	</div>
</div>

<br>

<div class="container">
	<div id="signup_form2" class="well">
		<h2><center><span class="glyphicon glyphicon-user"></span> Register Teacher</center></h2>
		<hr>
		<form action="insertTeacher.php" method="post">

    	<div style="height: 10px;"></div>	
        First Name:
        <input type="text" name="first_name" id="first_Name" class="form-control" rrequired>
    	
    	<div style="height: 10px;"></div>	
        Last Name:
        <input type="text" name="last_name" id="last_Name" class="form-control" required>
    
    	<div style="height: 10px;"></div>	
        Date Of Birth:
        <input type="date" name="age" id="age" class="form-control" required>
    	
    	<div style="height: 10px;"></div>	
        Contact No.:
        <input type="text" name="mobile" id="mobile" class="form-control" required>
    	
    	<div style="height: 10px;"></div>	
        Address:
        <input type="text" name="address" id="address" class="form-control" required>

        <div style="height: 10px;"></div>	
        Email:
        <input type="text" name="email" id="email" class="form-control" required>

        <div style="height: 10px;"></div>	
        Department:
        <input type="text" name="qualification" id="qualification" class="form-control" required>

        <div style="height: 10px;"></div>	
        start date:
        <input type="date" name="start_date" id="start_date" class="form-control" required>
    	
    	
    	
    	
    </p>
    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span> Register</button> 
</form>
	</div>
</body>
</html>