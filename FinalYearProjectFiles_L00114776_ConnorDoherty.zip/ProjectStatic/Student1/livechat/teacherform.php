<?php 

	session_start();
	
include "dbcon.php" ;	
	
	
if(!isset($_SESSION['id'])){

		header("location: index.php");

		exit;

	}
	
	

?>



<?php

include "db.php";

?>

<?php


if(isset($_POST['save'])){
	
	
	$name = $_POST['name'];
	$father_name = $_POST['father_name'];
	$age = $_POST['age'];
	$mobile = $_POST['mobile'];
	$address = $_POST['address'];
	$qlify = $_POST['qlify'];
	$admit_date = $_POST['admit_date'];
	$doctor = $_POST['doctor'];
	
	
	
	mysql_query("INSERT INTO `teacher` set name = '$name' , father_name = '$father_name' , age='$age' , mobile='$mobile' ,  address='$address' , disease='$qlify' , admit_date='$admit_date' , doctor='$doctor'") or die(mysql_error());
	
		header("refresh:2; url=addteacher.php");

	
	$flg_okay=0;
	$flg_okay=1;

}

if(isset($flg_okay)  && $flg_okay==1) { echo "Teacher have been Registered  successfully!"; }


?>






 <form action="" method="POST" enctype="multipart/form-data">
            <input type="text" name="name" placeholder="Teacher Name" class="form-control" style="width:40%;border-radius:8px;" required /><br/>
            
			<input type="text" name="father_name" placeholder=" Father Name" class="form-control" style="width:40%; border-radius:8px;" required /><br/>
            		    
			<input type="text" name="age" placeholder="Teacher Age" class="form-control" style="width:40%; border-radius:8px;" required /><br/>
            
			<input type="text" name="mobile" placeholder="Teacher Mobile No." class="form-control" style="width:40%; border-radius:8px;" required /><br/>

			<input type="text" name="address" placeholder="Teacher Address" class="form-control" style="width:40%; border-radius:8px;" required /><br/>
			
     		<input type="text" name="qlify" placeholder="Teacher Qualification" class="form-control" style="width:40%; border-radius:8px;" required /><br/>

			<input type="date" name="admit_date" placeholder="Teacher Registration Date" class="form-control" style="width:40%; border-radius:8px;" required /><br/>
			
			
			<input type="text" name="doctor" placeholder="Teacher Course Name" class="form-control" style="width:40%; border-radius:8px;" required /><br/>


			
		   <input type="submit" name="save" value="Save">


        </form>