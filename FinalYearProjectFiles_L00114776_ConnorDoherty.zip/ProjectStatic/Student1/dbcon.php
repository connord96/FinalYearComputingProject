<?php


####### db config ##########
	$db_username = 'root';
	$db_password = '';
	$db_name = 'student';
	$db_host = 'localhost';
####### db config end ##########


$dbname = $db_name;
$link = mysql_connect($db_host,$db_username,$db_password) or die("Couldn't make connection.");
$db = mysql_select_db($dbname, $link) or die("Couldn't select database");

?>