<?php 

	session_start();
	
include "dbcon.php" ;	
	
	
if(!isset($_SESSION['id'])){

		header("location: index.php");

		exit;

	}
	
	

?>

<?php

include "db.php";

?>



      <table border="4" class="table table-hover">
		 <thead>
         <tr class="success">
		     <th> ID </th>
			 <th> First Name </th>
			 <th> Surname </th>
			 <th> Age </th>
			 <th> Contact </th>
			 <th> Address </th>
			 <th> Email </th>
			 <th>  Course</th>
			 <th> Registeration Date </th>
			 
		 </tr>
		 </thead>
		 
		  <?php
		   $query = "SELECT * FROM `student`";
		   
		   $result = mysql_query($query);
		   
		   do{
			   $row = mysql_fetch_array($result);
			   
			   if($row) {
				   
				   $id = $row['id'];
				   $name = $row['name'];
			       $father_name = $row['father_name'];
				   $age = $row['age'];
				   $mobile = $row['mobile'];
				   $address = $row['address'];
				   $qualification = $row['qualification'];
				   $specialization = $row['specialization'];
				   $timing = $row['timing'];
				   
				   
		  ?>
		  <tbody>
		  <tr>
		    <td> <?php echo $id; ?> </td>
			<td> <?php echo $name; ?> </td>
			<td> <?php echo $father_name; ?> </td>
			<td> <?php echo $age; ?> </td>
			<td> <?php echo $mobile; ?> </td>
			<td> <?php echo $address; ?> </td>
			<td> <?php echo $qualification; ?> </td>
			<td> <?php echo $specialization; ?> </td>
			<td> <?php echo $timing; ?> </td>
		 </tr>
		 
		 
		 <?php
		 
			  }   
			   
		      }
		  
		      while($row);
		   ?>
		  </tbody>
       </table>	  


