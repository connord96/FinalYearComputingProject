<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Student Data</title>
</head>
<body>
<form action="insert.php" method="post">
    <p>
        <label for="firstName">First Name:</label>
        <input type="text" name="first_name" id="firstName" required>
    </p>
    <p>
        <label for="lastName">Last Name:</label>
        <input type="text" name="last_name" id="lastName" required>
    </p>
    <p>
        <label for="age">Date Of Birth:</label>
        <input type="date" name="age" id="age" required>
    </p>
    <p>
        <label for="mobile">Contact No.:</label>
        <input type="text" name="mobile" id="mobile" required pattern="[0-9][15]">
    </p>
    <p>
        <label for="address">Address:</label>
        <input type="text" name="address" id="address" required>
    </p>
    <p>
        <label for="qualification">Email:</label>
        <input type="email" name="qualification" id="qualification" required>
    </p>
    <p>
        <label for="specialization">Course Name:</label>
        <input type="text" name="specialization" id="specialization" required>
    </p>
    <p>
        <label for="timing">Start Date:</label>
        <input type="date" name="timing" id="timing" required>
    </p>
    <input type="submit" value="Submit">
</form>
</body>
</html>