<html>
<head>
<title> Captcha </title>
<style>
#randomfield { 
-webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none; 
  width: 200px;
  color: black;
  border-color: black;
  text-align: center;
  font-size: 40px;
  background-image: url('images/captchaBackground1.jpg');
}
</style>

<!-- Bootstrap core CSS -->
    <link href="../bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../homeStyle.css" rel="stylesheet">

</head>
<body onLoad="ChangeCaptcha()">

  <div class="container">

      <div class="masthead">
        <h3 class="text-muted">Educational Website</h3>

        <nav class="navbar navbar-light bg-faded rounded mb-3">
                    
            <ul class="nav navbar-nav text-md-center justify-content-md-between">
              <li class="nav-item active">
                <a class="nav-link" href="../../home.php">Home </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../../CoursesList.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Search Timetables</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../livechat/index.php">Student Live-Chat</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../indexSearch.php">Search Responses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../../adminControl.php">Admin</a>
              </li>
              </li>
            </ul>
          
        </nav>
      </div>

<input type="text" id="randomfield" disabled>

<script>
function ChangeCaptcha() {
	var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
	var string_length = 6;
	var ChangeCaptcha = '';
	for (var i=0; i<string_length; i++) {
		var rnum = Math.floor(Math.random() * chars.length);
		ChangeCaptcha += chars.substring(rnum,rnum+1);
	}
	document.getElementById('randomfield').value = ChangeCaptcha;
}
function check() {
if(document.getElementById('CaptchaEnter').value == document.getElementById('randomfield').value ) {
  window.alert('Welcome to your Account!')
window.open('user/','_self');
}
else {
alert('Please re-check the captcha');
}
}
</script>
<br><br>
<input id="CaptchaEnter" size="20" maxlength="6" />
<br><br>
<button onclick="check()">Done</button>

<!-- Site footer -->
      <footer class="footer">
        <p>&copy; Connor Doherty (LYIT)</p>
      </footer>
      
</body>
</html>