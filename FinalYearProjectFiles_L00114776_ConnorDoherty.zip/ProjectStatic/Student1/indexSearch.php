
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Search Responses</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="homeStyle.css" rel="stylesheet">

    <style>
      #body1{
        background-color: #fff#fff;
      }

    </style>
  </head>

  <body>
<div class="body1">
    <div class="container">

      <div class="masthead">
        <h3 class="text-muted">Educational Website</h3>

        <nav class="navbar navbar-light bg-faded rounded mb-3">
                    
            <ul class="nav navbar-nav text-md-center justify-content-md-between">
              <li class="nav-item active">
                <a class="nav-link" href="../home.php">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../CoursesList.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Search Timetables</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="livechat/index.php">Student Live-Chat</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="indexSearch.php">Search Responses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../adminControl.php">Admin</a>
              </li>
              </li>
            </ul>
          
        </nav>
      </div>

      <form action="search.php" method="GET">
    <input type="text" name="query" />
    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-log-in"></span> Search</button>
    </form>



      <!-- Site footer -->
      <footer class="footer">
        <p>&copy; Connor Doherty (LYIT)</p>
      </footer>

    </div> <!-- /container -->
  </div>

  </body>
</html>
