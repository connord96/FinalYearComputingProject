<!doctype html>
<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/bootstrap-theme.min.css" type="text/css" rel="stylesheet" />
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="styles.css">
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="script.js"></script>
   <title>CSS MenuMaker</title>
</head>



<div id='cssmenu'>
<ul>
   <li><a href='home1.php'><span>Home</span></a></li>
   <li class='active has-sub'><a href='#'><span>Register</span></a>
   <ul>
               <li class='last'><a href='addstudent.php'><span>Register A Student</span></a></li>
               <li class='last'><a href='addTeacher.php'><span>Register A Teacher</span></a></li>
               
            </ul>
         </li>
 <li class='active has-sub'><a href='#'><span>Registered Members</span></a>
   <ul>
               <li class='last'><a href='student.php'><span>All Students</span></a></li>
               <li class='last'><a href='teacher.php'><span>All Teachers</span></a></li>
               
            </ul>
    </li>     
   
  
   
   <li class='last'><a href='contact.php'><span>Contact</span></a></li>
</ul>
</div>
			 
 
</html>