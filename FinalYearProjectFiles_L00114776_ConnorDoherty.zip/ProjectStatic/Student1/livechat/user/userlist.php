<!--list-->
<div class="col-lg-12">
    <div class="panel panel-default" style="height:50px;">
		<span style="font-size:18px; margin-left:10px; position:relative; top:13px;"><strong><span class="glyphicon glyphicon-user"></span> User List</strong></span>
		<div class="pull-right" style="margin-right:10px; margin-top:7px;">
			
		</div>
	</div>
	<table width="100%" class="table table-striped table-bordered table-hover" id="userList">
        <thead>
            <tr>
                <th>Name</th>
				<th>Age</th>
				<th>Course</th>
				<th>Student ID</th>
			</tr>
		</thead>
		<tbody>
		<?php
			$query=mysqli_query($conn,"select * from `student` order by name asc");
			while($row=mysqli_fetch_array($query)){
			?>
			<tr>
				<td><input type="hidden" id="ename<?php echo $row['id']; ?>" value="<?php echo $row['name']; ?>"><?php echo $row['name']; ?></td>
				<td><input type="hidden" id="eusername<?php echo $row['id']; ?>" value="<?php echo $row['age']; ?>"><?php echo $row['age']; ?></td>
				<td><input type="hidden" id="epassword<?php echo $row['id']; ?>" value="<?php echo $row['qualification']; ?>"><?php echo $row['qualification']; ?></td>
				<td><input type="hidden" id="epassword<?php echo $row['id']; ?>" value="<?php echo $row['id']; ?>"><?php echo $row['id']; ?></td>
			</tr>
			<?php
			}
		?>
        </tbody>
    </table>                     
</div>