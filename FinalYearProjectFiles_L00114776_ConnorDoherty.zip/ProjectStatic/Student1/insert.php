<html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<body>
<div class="container">
	<div id="signup_form" class="well">
		<h2><center><span class="glyphicon glyphicon-user"></span><a href="Addstudent.php"> Return </center></a></h2>
	</div>
</div>
</body>
</html>


<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "student");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 


if(isset($_POST['submit'])){
    $name = isset($_POST['first_name']) ? $_POST['name'] : null;
    $email = isset($_POST['last_name']) ? $_POST['email'] : null;
    $extraInfo = isset($_POST['age']) ? $_POST['age'] : null;
}



 
if(!empty($errors)){ 
    echo '<h1>Error(s)!</h1>';
    foreach($errors as $errorMessage){
        echo $errorMessage . '<br>';
    }
} 


// Escape user inputs for security
$first_name = mysqli_real_escape_string($link, $_REQUEST['first_name']);
$last_name = mysqli_real_escape_string($link, $_REQUEST['last_name']);
$age = mysqli_real_escape_string($link, $_REQUEST['age']);
$mobile = mysqli_real_escape_string($link, $_REQUEST['mobile']);
$address = mysqli_real_escape_string($link, $_REQUEST['address']);
$qualification = mysqli_real_escape_string($link, $_REQUEST['qualification']);
$specialization = mysqli_real_escape_string($link, $_REQUEST['specialization']);
$timing = mysqli_real_escape_string($link, $_REQUEST['timing']);

// attempt insert query execution
$sql = "INSERT INTO student (name, father_name, age, mobile, address, qualification, specialization, timing) VALUES ('$first_name', '$last_name', '$age', '$mobile', '$address', '$qualification', '$specialization', '$timing')";
if(mysqli_query($link, $sql)){
	echo '<script language="javascript">';
	echo 'alert("Student Registered!")';
    echo '</script>';
} else{
    echo "ERROR: Unable to Execute! Please Return " . mysqli_error($link);
}



// close connection
mysqli_close($link);
?>
