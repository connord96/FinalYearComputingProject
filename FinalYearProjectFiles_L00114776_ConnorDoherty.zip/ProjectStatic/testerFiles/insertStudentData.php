<?php

	$con = mysql_connect('localhost', 'root','');

	if(!$con)
		{
			echo 'not connected to server';
		}

		if(!mysql_select_db('student'))
		{
			echo ' Database not selected';
		}

		$Name=$_POST['name'];
		$Surname=$_POST['surname'];
		$Age=$_POST['age'];
		$Contact=$_POST['contact'];
		//$Address=$_POST['address'];
		$Qualification=$_POST['qualification'];
		//$Department=$_POST['department'];


		$sql = "INSERT INTO student (Name, father_name, age, mobile, qualification) VALUES ('$Name', '$Surname', $Age, $Contact, $Qualification)";

		if(!mysql_query($sql))
		{
			echo 'Not Inserted';
		}

		else
		{
			echo 'Inserted';
		}

?>