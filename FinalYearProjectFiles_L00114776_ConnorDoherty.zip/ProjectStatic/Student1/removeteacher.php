<?php


include "db.php"; 


$selected_record = $_REQUEST['id'];



mysql_query("DELETE FROM `teacher` where id = '$selected_record' ");


header("location: teacher.php");




?>