
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>B.Sc. In Sports Coaching and Performance</title>

    <!-- Bootstrap core CSS -->
    <link href="../bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../homeStyle.css" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <style>
      #body1{
        background-color: #ffffff;
      }

    </style>
  </head>

  <body>
    <div class="body1">
    <div class="container">

      <div class="masthead">
        <h3 class="text-muted">Educational Website</h3>

        <nav class="navbar navbar-light bg-faded rounded mb-3">
                    
            <ul class="nav navbar-nav text-md-center justify-content-md-between">
              <li class="nav-item active">
                <a class="nav-link" href="../../home.php">Home<span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../../CoursesList.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../../TimetablesList.php">Search Timetables</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../livechat/index.php">Student Live-Chat</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/indexSearch.php">Search Responses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../../adminControl.php">Admin</a>
              </li>
              </
            </ul>
          
        </nav>
    </div>



    <div class="container">
  <h2>B.Sc. In Sports Coaching and Performance (Level 8)</h2>

  <div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Requirements</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse">
        <div class="panel-body">

        <ul>
          <li>345 Leaving Certificate Points</li>
          <li>Minimum six O6/H7</li>
          <li>Next available starting date is September 2018</li>
        </ul>
        </div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Course Outline</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">

        <p><b>Year 1 · College Studies</b>
          <br>
<p>Modules to be covered include Sports Coaching Techiniques, Kickstart 1 and 2 (Official FAI badges), Fitness in Sport and Elite Performances in Porffesional atheletes. These modules provide students with the ability to coach and understand performance at a basic level.</p>

<p><b>Year 2 · Placement</b>
  <br>
<p>Students take this year as an opportunity to engage on life outside of college within a working environment. Students can take up voluntary work with local sports organisations and compile a report at the end of the 12 weeks of their knowledge gained from within the organisation. </p>

<p><b>Year 3 · College Studies</b>
  <br>
<p>Students take this year to compile a research report into sports performance by analysing on-field performances and producing a write-up based on player performance, technique, speed and other traits. Provides students with the ability to assess performance on-field and provide recommendations for improvements outside the sports field.</p>

        </div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Further Education</a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="panel-body"><p> Following the completion of this course, students can apply for an M.Sc. In a related subject. Others may choose to take up employment in the sports sector as trainee coaches, sports analysts etc.</p>
        </div>
      </div>
    </div>
  </div> 
</div>

<p>For Further Information, Please use the link provided below:</p>
<button class="btn btn-info btn-md"><span class="glyphicon glyphicon-log-in"></span><a href="../../contact.php"> Contact</a></button> 


      <!-- Site footer -->
      <footer class="footer">
        <p>&copy; Connor Doherty (LYIT)</p>
      </footer>

    </div> <!-- /container -->
  </div>
  </body>
</html>
