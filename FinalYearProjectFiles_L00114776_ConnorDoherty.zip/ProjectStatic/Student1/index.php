<?php

	session_start();

	$flg_submit=false;

	$flg_login=0;

	if(isset($_POST['login'])){

		require("dbcon.php");

		$flg_submit=true;

		$username = $_POST['user'];

		$pass = $_POST['pass'];
		
		 

		$res = mysql_query("select * from `login` where user='$username' and pass='$pass'");
		
		
		if(mysql_num_rows($res)>0){

			$row = mysql_fetch_assoc($res);
			
			$flg_login=1;	

			$_SESSION['id']= $row['id'];


			$_SESSION['user'] = true;

			$_SESSION['u'] = $row['user'];
			
			
			header("refresh: 2; url=home1.php");

		}else{

			$flg_login=2;	//fail


		}

	}
	
	
	

	?>
	
	
	



<html>
<head> <title> Student and Teacher Management System </title> 


<link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Latest Ajax -->
    <script src="js/jquery.min.js"></script>
  

<link rel="stylesheet" href="css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="js/bootstrap.min.js"></script>





</head>







<body>
   <div class="container">
	 
<div class="jumbotron" style="height:150px;background-color:lightblue;line-height:30px"> 
 <b><font style="font-size:30px;">Student and Teacher Management System</font></b>
 
 <br><a href="../Student/livechat/index.php">Live Chat</a></br>
 <a href="indexSearch.php">Search Replies</a>
 
 </div>

	 
	<div class="row">
		<div class="col-sm-8">
		<h3>Purpose </h3>
		
		
		<h3> How You Can Use It </h3>
		<p>
		   <li>Type Your Username And Password</a></li> 
		   <li>Then click on <a>Login</a></li>
          <li> Then you enter the Admin panel where you can register students and teachers and view all members</li>
          	  
		</p>
		
		</div>
		
		<div class="col-sm-4">
		<h3>Click here for login </h3>
		
		<form action="" method="POST" enctype="multipart/form-data">
		
		        
<?php if($flg_login==2){ ?>

<span style="color: red;">Invalid Login Details! </span>

<?php }elseif($flg_login==1){ ?>

Login successful

<?php } ?>
		
		
            Userame <input type="text" name="user" placeholder="Type Your User Name" class="form-control" style="width:80%;border-radius:8px;" required /><br/>
            Password<input type="password" name="pass" placeholder="Type Password" class="form-control" style="width:80%; border-radius:8px;" required /><br/>
		    <input type="submit" name="login" value="Log in">

        </form>
		   
		   
		   
            </div>
        </div>

  </div>



</body>



</html>