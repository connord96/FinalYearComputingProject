<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Search</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
     <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="homeStyle.css" rel="stylesheet">
</head>
<body>

     <div class="container">

      <div class="masthead">
        <h3 class="text-muted">Educational Website</h3>

        <nav class="navbar navbar-light bg-faded rounded mb-3">
                    
            <ul class="nav navbar-nav text-md-center justify-content-md-between">
              <li class="nav-item active">
                <a class="nav-link" href="../home.php">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../CoursesList.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Search Timetables</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="livechat/index.php">Student Live-Chat</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="indexSearch.php">Search Responses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../adminControl.php">Admin</a>
              </li>
              </li>
            </ul>
          
        </nav>
      </div>
      <br>

 <?php
    mysql_connect("localhost", "root", "") or die("Error connecting to database: ".mysql_error());
     
    mysql_select_db("student") or die(mysql_error());

?>

<h3><b>Your Search Results Are As Follows:</b></h2>
    <br>

<?php
    $query = $_GET['query']; 
    // gets value sent over search form
     
    $min_length = 3;
    
     
    if(strlen($query) >= $min_length){ 
         
        $query = htmlspecialchars($query); 
         
        $query = mysql_real_escape_string($query);
        // makes sure nobody uses SQL injection
         
        $raw_results = mysql_query("SELECT * FROM chat
            WHERE (`message` LIKE '%".$query."%') OR (`chat_date` LIKE '%".$query."%')") or die(mysql_error());
         
        if(mysql_num_rows($raw_results) > 0){ // if one or more rows are returned do following
             
            while($results = mysql_fetch_array($raw_results)){
            // $results = mysql_fetch_array($raw_results) puts data from database into array, while it's valid it does the loop
             
                echo "<ul><li><p><h4>".$results['message']."</h4>".$results['chat_date']."</p><br></li></ul>";
                // posts results gotten from database
            } 
        }
        else{ // if there is no matching rows
            echo "No results Available, Please Try Again"; 
        }
         
    }
    else{ // if query length is less than minimum
        echo "Minimum length is ".$min_length;
    }
?>
 
 
 
  <!-- Site footer -->
      <footer class="footer">
        <p>&copy; Connor Doherty (LYIT)</p>
      </footer>

</body>
</html>