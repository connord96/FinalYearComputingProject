<html>
<head> <title> Register a New Student </title> 


<link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Latest Ajax -->
    <script src="js/jquery.min.js"></script>
  

<link rel="stylesheet" href="css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="js/bootstrap.min.js"></script>




</head>







<body>
   <div class="container">
	 <?php
           include "header.php";
	   ?>      
		<div class="row">
		   <div class="col-md-4">
           
			 
			  <?php
                  include "sidebar.php";
              ?>
			 
			 
		   
		   
		   
		   
            </div>
			
			<?php
		   
		     include "livechat/signup.php"; 	
		  	?>

		  	
		  
		   <div style="" class="col-md-8">
		   
		   		   
            </div>
        </div>



  </div>



</body>



</html>