<html>
<head> <title> Admin Home Page </title> 


<link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Latest Ajax -->
    <script src="js/jquery.min.js"></script>
  

<link rel="stylesheet" href="css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="js/bootstrap.min.js"></script>





</head>







<body>
   <div class="container">
	 <?php
           include "header.php";
	   ?>      
		<div class="row">
		   <div class="col-md-4">
           
			 
			  <?php
                  include "sidebar.php";
              ?>
			 
			 
		   
		   
		   
		   
            </div>
			
			
		   <div class="col-md-8">
		   
		   
		  <?php
		    // include "doctorform.php";
		  ?>
		   
            </div>
        </div>



  </div>



</body>



</html>