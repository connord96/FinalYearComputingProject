

 <div class="jumbotron" style="height:150px;background-color:lightblue;line-height:30px"> 
 <b><font style="font-size:30px;">Student and Teacher Management System</font></b>
 
 <a  href="../../adminControl.php"><button type="button" style="float:right"> LOGOUT </button></a></div>
 

