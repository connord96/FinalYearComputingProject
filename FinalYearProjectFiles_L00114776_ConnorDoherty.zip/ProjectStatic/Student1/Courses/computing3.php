
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>B.Sc. In Computer Forensics</title>

    <!-- Bootstrap core CSS -->
    <link href="../bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../homeStyle.css" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <style>
      #body1{
        background-color: #ffffff;
      }

    </style>
  </head>

  <body>
    <div class="body1">
    <div class="container">

      <div class="masthead">
        <h3 class="text-muted">Educational Website</h3>

        <nav class="navbar navbar-light bg-faded rounded mb-3">
                    
            <ul class="nav navbar-nav text-md-center justify-content-md-between">
              <li class="nav-item active">
                <a class="nav-link" href="../../home.php">Home<span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../../CoursesList.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../../TimetablesList.php">Search Timetables</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../livechat/index.php">Student Live-Chat</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/indexSearch.php">Search Responses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../../adminControl.php">Admin</a>
              </li>
              </
            </ul>
          
        </nav>
    </div>



    <div class="container">
  <h2>B.Sc. In Computer Forensics (Level 8)</h2>

  <div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Requirements</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse">
        <div class="panel-body">

        <ul>
          <li>345 Leaving Certificate Points</li>
          <li>Minimum five O6/H7</li>
          <li>Next available starting date is September 2018</li>
        </ul>
        </div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Course Outline</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">

        <p><b>Year 1 · College Studies</b>
          <br>
<p>Modules to be covered include Introduction to Programming, Digital Forensics, Software Implementation and Security. This year takes in Continuous Assesment (C.A) and Written Examinations towards the end of the year worth 40% overall.</p>

<p><b>Year 2 · College Studies</b>
  <br>
<p>Modules include a more in-depth look into the first year topics covered. Additional topics include Operating Systems and Database Administration as well as a look into the Laws of Forensics and Forensic Algorithms. Several guest speakers come in to deliver speeches surrounding the area of study at that time. A great opportunity for students to get to know the field of work.</p>

<p><b>Year 3 · College Studies</b>
  <br>
<p>The final year provides students with the ability to test their knowledge of topics with the final year dissertation and research project. This takes up a chunk of the year along with other modules such as Forensics in the Future, Applied Methodologies with Computer Security and Data Protection</p>

        </div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Further Education</a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="panel-body"><p> Students, following the completion of the B.Sc. degree may move on to an M.Sc. in a related topic of choice. Likewise, students would be in a position to apply for job openings in the computing sector.</p>
        </div>
      </div>
    </div>
  </div> 
</div>

<p>For Further Information, Please use the link provided below:</p>
<button class="btn btn-info btn-md"><span class="glyphicon glyphicon-log-in"></span><a href="../../contact.php"> Contact</a></button> 


      <!-- Site footer -->
      <footer class="footer">
        <p>&copy; Connor Doherty (LYIT)</p>
      </footer>

    </div> <!-- /container -->
  </div>
  </body>
</html>
