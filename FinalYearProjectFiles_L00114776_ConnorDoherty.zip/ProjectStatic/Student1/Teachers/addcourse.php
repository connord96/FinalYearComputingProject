<?php
 session_start();
 //$r=session_id();
 //echo "the session id id: ".$r;

?>

<html>
<head> <title> Welcome to Teacher Penal </title> 


<link rel="stylesheet" href="../css/bootstrap.min.css">

    <!-- Latest Ajax -->
    <script src="../js/jquery.min.js"></script>
  

<link rel="stylesheet" href="../css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="../js/bootstrap.min.js"></script>


<style>
#p {
    border-style: solid;
    border-color:#0000ff;
}
#submit {
	border-radius:30px;
	width:20px;
	background-color:	#00FFFF;
    border-style: solid;
    border-color: #00FFFF;
}
#publish {
	border-radius:30px;
	width:150px;
	height:35px;
	background-color:#F5F5DC;
    border-style: solid;
    border-color:#006400;
}
#title{
	border-radius:0px;
	width:20px;
	background-color:		#87CEFA;
    border-style: solid;
    border-color:#FFA07A;


</style>








</head>







<body>
   <div class="container">
	 
<div class="jumbotron" style="height:150px;background-color:lightblue;line-height:30px"> 
 <b><font style="font-size:30px;">Welcome to Teacher Penal</font></b>
 
     <a  href="logout.php"><button type="button" style="float:right"> LOGOUT </button></a></div>
 
 </div>

	<center>
	       <table>
        <tr><td><ul><li><a href="home.php">Home</a></li></ul></td>
        <td><ul><li><a href="addcourse.php">Add Course</a></li></ul></td>
       
        
        </table>
	
	
	</center> 
	 
	 
	 
	 <form action="addcourse.php" method="POST">
	    <table align="center" width="700">
		
		<tr>
		      <td>Title</td>
		      <td><input type="text"></input></td>
		</tr>
		
		
		
		</table>
	 
	 </form>
	 
	 
	 
	 
	 
</body>
</html>

<?php
//MySQLi Procedural
$conn = mysqli_connect("localhost","root","","student");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}




if(isset($_POST['Submit'])){
	       
		    
			 $title = $_POST['title'];
			 
			 $q = "INSERT INTO `course`(`title`) VALUES ('$title')";
			 
			 mysql_query($q);
	 
	 }
	 

?>

