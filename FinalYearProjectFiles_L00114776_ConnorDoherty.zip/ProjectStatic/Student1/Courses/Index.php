

<html>
<head> <title> Welcome to the Class Room sections </title> 


<link rel="stylesheet" href="../css/bootstrap.min.css">

    <!-- Latest Ajax -->
    <script src="../js/jquery.min.js"></script>
  

<link rel="stylesheet" href="../css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="../js/bootstrap.min.js"></script>











</head>







<body>
   <div class="container">
	 
<div class="jumbotron" style="height:150px;background-color:lightblue;line-height:30px"> 
 <b><font style="font-size:30px;">Welcome to the Class Room sections</font></b>
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 

                 <a href="../livechat/">Live Chat</a>&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                 <a href="../teachers/index.php">Teacher Login</a>
                 <a href="../index.php">HomePage</a>
 
 </div>

	 
	


</body>



</html>