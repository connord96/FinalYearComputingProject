<?php




?>

<html>
<head> <title> Welcome to Teacher Penal </title> 


<link rel="stylesheet" href="../css/bootstrap.min.css">

    <!-- Latest Ajax -->
    <script src="../js/jquery.min.js"></script>
  

<link rel="stylesheet" href="../css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="../js/bootstrap.min.js"></script>











</head>







<body>
   <div class="container">
	 
<div class="jumbotron" style="height:150px;background-color:lightblue;line-height:30px"> 
 <b><font style="font-size:30px;">Welcome to Teacher Penal</font></b>
 
     <a  href="logout.php"><button type="button" style="float:right"> LOGOUT </button></a></div>
 
 </div>

	<center>
	       <table>
        <tr><td><ul><li><a href="home.php">Home</a></li></ul></td>
        <td><ul><li><a href="addcourse.php">Add Course</a></li></ul></td>
        
        
        </table>
	
	
	</center> 
	
</div>

</body>



</html>