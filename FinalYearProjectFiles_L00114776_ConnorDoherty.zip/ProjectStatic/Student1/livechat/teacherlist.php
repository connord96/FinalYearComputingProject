<?php 

	//session_start();
	
include "dbcon.php" ;	
	
	
if(!isset($_SESSION['id'])){

		header("location: index.php");

		exit;

	}
	
	

?>


<?php

include "db.php";

?>



      <table border="4" class="table table-hover">
		 <thead>
         <tr class="success">
		     <th> ID </th>
			 <th> Teacher Name </th>
			 <th> Father Name </th>
			 <th> Teacher Age </th>
			 <th> Teacher Mobile No </th>
			 <th> Teacher Address </th>
			 <th> Teacher Qualification  </th>
			 <th> Registration Date </th>
			 <th> Teacher Course  </th>
			 
		 </tr>
		 </thead>
		 
		  <?php
		   $query = "SELECT * FROM `teacher`";
		   
		   $result = mysql_query($query);
		   
		   do{
			   $row = mysql_fetch_array($result);
			   
			   if($row) {
				   
				   $id = $row['id'];
				   $name = $row['name'];
				   $father_name = $row['father_name'];
				   $age = $row['age'];
				   $mobile = $row['mobile'];
				   $address = $row['address'];
				   $qualification = $row['qualification'];
				   $start_date = $row['start_date'];
				   $email = $row['email'];
				   
				   
		  ?>
		  <tbody>
		  <tr>
		    <td> <?php echo $id; ?> </td>
			<td> <?php echo $name; ?> </td>
			<td> <?php echo $father_name; ?> </td>
			<td> <?php echo $age; ?> </td>
			<td> <?php echo $mobile; ?> </td>
			<td> <?php echo $address; ?> </td>
			<td> <?php echo $qualification; ?> </td>
			<td> <?php echo $start_date; ?> </td>
			<td> <?php echo $email; ?> </td>
			<!--<td><a href="removeteacher.php?id=<?php echo $id; ?>"> Delete </a> </td>-->

		 </tr>
		 
		 
		 <?php
		 
			  }   
			   
		      }
		  
		      while($row);
		   ?>
		  </tbody>
       </table>	  


