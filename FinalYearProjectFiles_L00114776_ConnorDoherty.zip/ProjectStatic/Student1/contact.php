<?php 

	session_start();
	
include "dbcon.php" ;	
	
	
if(!isset($_SESSION['id'])){

		header("location: index.php");

		exit;

	}
	
	

?>



<html>
<head> <title> Contact to Developer </title> 

<meta name="viewport" content="width=device-width, initial-scale=1.0">



<link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Latest Ajax -->
    <script src="js/jquery.min.js"></script>

  

<link rel="stylesheet" href="css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="js/bootstrap.min.js"></script>





</head>







<body>
   <div class="container">
	 <?php
           include "header.php";
	   ?>      
		<div class="row">
		   <div class="col-md-3">
           
			 
			  <?php
                  include "sidebar.php";
              ?>
			 
			 
		   
		   
		   
		   
            </div>
			
			
		   <div class="col-md-9">
		   
		   
		  		<br/>
		<font color="#3399ff"><h2>CONTACT US</h2></font>
		<hr/ color="pink" width="610" align="left">
		<b>ADDRESS: </b></td> <td>The College, The Long Road, Letterkenny, F9FVY4 &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp <b>Contact No:</b> (074) 9338271
		<hr/ color="lightblue" width="610" align="left">
		   
            </div>
        </div>



  </div>



</body>



</html>