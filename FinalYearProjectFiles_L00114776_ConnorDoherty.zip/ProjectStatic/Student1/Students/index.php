
	
	
	



<html>
<head> <title> Student and Teacher Management System </title> 


<link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Latest Ajax -->
    <script src="js/jquery.min.js"></script>
  

<link rel="stylesheet" href="css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="js/bootstrap.min.js"></script>





</head>







<body>
   <div class="container">
	 
<div class="jumbotron" style="height:150px;background-color:lightblue;line-height:30px"> 
 <b><font style="font-size:30px;">Welcome to Student Penal</font></b>
 
 
 </div>

	 
	<div class="row">
		
		
		<div class="col-sm-4">
		<h3>Click here for Student login </h3>
		
		<form action="" method="POST" enctype="multipart/form-data">
		
		        
<?php if($flg_login==2){ ?>

<span style="color: red;">Invalid Login Details! </span>

<?php }elseif($flg_login==1){ ?>

Login successful

<?php } ?>
		
		
            Userame <input type="text" name="user" placeholder="Type Your User Name" class="form-control" style="width:80%;border-radius:8px;" required /><br/>
            Password<input type="password" name="pass" placeholder="Type Password" class="form-control" style="width:80%; border-radius:8px;" required /><br/>
		    <input type="submit" name="login" value="Log in">

        </form>
		   
		   
		   
            </div>
        </div>



  </div>



</body>



</html>