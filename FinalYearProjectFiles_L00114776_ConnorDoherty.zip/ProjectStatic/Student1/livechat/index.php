<!DOCTYPE html>
<html>
<head>
	<title>Student and Teacher Chat System</title>
	

		 <!-- Bootstrap core CSS -->
    <link href="../bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../homeStyle.css" rel="stylesheet">
<style>
	#login_form{
		width:350px;
		height:350px;
		position:relative;
		top:50px;
		margin: auto;
		padding: auto;
	}
</style>
</head>

<body>

	<div class="container">

      <div class="masthead">
        <h3 class="text-muted">Educational Website</h3>

        <nav class="navbar navbar-light bg-faded rounded mb-3">
                    
            <ul class="nav navbar-nav text-md-center justify-content-md-between">
              <li class="nav-item active">
                <a class="nav-link" href="../../home.php">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../../CoursesList.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../../TimetablesList.php">Search Timetables</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="index.php">Student Live-Chat</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="searchHome.php">Search Responses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../../adminControl.php">Admin</a>
              </li>
              </li>
            </ul>
          
        </nav>
      </div>
    </div>

<div class="container">
	<div id="login_form" class="well">
		<h2><center><span class="glyphicon glyphicon-lock"></span> Please Login</center></h2>
		<hr/>
		<form method="POST" action="login.php">
		Username: <input type="text" name="username" class="form-control" required>
		<div style="height: 10px;"></div>		
		Password: <input type="password" name="password" class="form-control" required> 
		<div style="height: 10px;"></div>
		<button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-log-in"></span> Login</button> No account? <a href="signup.php"> Sign up</a>
		</form>
		<div style="height: 15px;"></div>
		<div style="color: red; font-size: 15px;">
			<center>
			<?php
				session_start();
				if(isset($_SESSION['msg'])){
					echo $_SESSION['msg'];
					unset($_SESSION['msg']);
				}
			?>
			</center>
		</div>
	</div>

<br>
<br>

<footer class="footer">
        <p>&copy; Connor Doherty (LYIT)</p>
</footer>

</div>
</body>
</html>