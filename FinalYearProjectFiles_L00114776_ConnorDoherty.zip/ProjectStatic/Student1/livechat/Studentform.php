<?php 

	session_start();
	
include "dbcon.php" ;	
	
	
if(!isset($_SESSION['id'])){

		header("location: index.php");

		exit;

	}
	

	

?>


<?php


include "db.php";

?>

<?php





if(isset($_POST['save'])){
	
	
	$name = $_POST['name'];
	$father_name = $_POST['father_name'];
	$age = $_POST['age'];
	$mobile = $_POST['mobile'];
	$address = $_POST['address'];
	$qualification = $_POST['qualification'];
	$specialization = $_POST['specialization'];
	$timing = $_POST['timing'];
	
	
	
	
	
	mysql_query("INSERT INTO `student` set name = '$name' , father_name = '$father_name' , age='$age' , mobile='$mobile' ,  address='$address' , qualification='$qualification' , specialization='$specialization' , timing='$timing'") or die(mysql_error());
	
	
	 header("refresh:2; url=addstudent.php");

	
	$flg_okay=0;
	$flg_okay=1;

}

if(isset($flg_okay)  && $flg_okay==1) { echo "Student have been Registered  successfully!"; }


?>


 <form action="" method="POST" enctype="multipart/form-data">
 <table>
            <input type="text" name="name" placeholder="Name" class="form-control" style="width:40%;border-radius:8px;" required /><br/>
            
			<input type="text" name="father_name" placeholder="Father Name" class="form-control" style="width:40%; border-radius:8px;" required /><br/>
            		    
			<input type="text" name="age" placeholder="Age" class="form-control" style="width:40%; border-radius:8px;" required /><br/>
            
			<input type="text" name="mobile" placeholder="Mobile No." class="form-control" style="width:40%; border-radius:8px;" required /><br/>

			<input type="text" name="address" placeholder=" Address" class="form-control" style="width:40%; border-radius:8px;" required /><br/>
			
     		<input type="text" name="qualification" placeholder="Qualification" class="form-control" style="width:40%; border-radius:8px;" required /><br/>

			<input type="date" name="specialization" placeholder="Specialization" class="form-control" style="width:40%; border-radius:8px;" required /><br/>
			
			
			<input type="text" name="timing" placeholder="Course" class="form-control" style="width:40%; border-radius:8px;" required /><br/>


			
		   <input type="submit" name="save" value="Save">
</table>

        </form>