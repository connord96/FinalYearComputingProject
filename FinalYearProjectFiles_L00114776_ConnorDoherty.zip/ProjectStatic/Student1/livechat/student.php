



<html>
<head> <title> Total List of the Students </title> 

<meta name="viewport" content="width=device-width, initial-scale=1.0">



<link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Latest Ajax -->
    <script src="js/jquery.min.js"></script>

  

<link rel="stylesheet" href="css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="js/bootstrap.min.js"></script>





</head>







<body>
   <div class="container">
	 <?php
           include "header.php";
	   ?>      
		<div class="row">
		   <div class="col-md-3">
           
			 
			  <?php
                  include "sidebar.php";
              ?>
			 
			 
		   
		   
		   
		   
            </div>
			
			
		   <div class="col-md-9">
		   
		   
		  <?php
		     include "studentlist.php";
		  ?>
		   
            </div>
        </div>



  </div>



</body>



</html>